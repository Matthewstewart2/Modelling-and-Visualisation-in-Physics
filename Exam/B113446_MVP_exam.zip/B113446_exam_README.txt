Exam no.: B113446

dt of 0.1 or 0.01 both seemed to work.

part b) The pde is a reaction diffusion equation. So species diffuse meaning
	concentrations spead out while reactions transform species types.
	Initially, the diffusion means everything becomes type 0 (all low
	concentration) but eventially the reactions to one particular type take
	over and transform whole lattice into one type.

part c) mean absorption time was 108 time units with standard error on the mean
	of 16.

part d) The decreased diffusivity meas the species spread out less which means
	there are now pockets of the dark blue which is where all three species
	are low concentration.

part e) Graph shows both points have concentration oscillations of type A with
	a period of about 50 time units (from visual inspection, would fit sin
	wave with more time).

I did not attempt part f)